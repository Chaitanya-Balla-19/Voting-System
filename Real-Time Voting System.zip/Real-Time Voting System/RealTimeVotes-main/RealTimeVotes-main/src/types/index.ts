export interface AppElement {
  name: string;
  id: string;
  votes: string;
};

export type AppList = AppElement[];
